﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MrVeggie.Models.Pages {

    public class AgendaReceitas {

        public List<Agenda> agenda;
        public List<Receita> receitas;
    }
}
